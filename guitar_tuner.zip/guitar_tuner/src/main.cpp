#include <Arduino.h>

// --- Definicje pinów (zgodnie z Twoim schematem) ---
const int PIN_STEP = 5;      // D5 steruje krokiem silnika
const int PIN_DIR  = 6;      // D6 steruje kierunkiem obrotów

const int PIN_SW1  = 7;      // Przycisk 1 (D7)
const int PIN_SW2  = 8;      // Przycisk 2 (D8)
const int PIN_SW3  = 9;      // Przycisk 3 (D9)

const int PIN_AUDIO_IN = A0; // Wyjście OUT z MCP6002 podłączone pod A0

// --- Parametry silnika ---
const int STEP_DELAY = 2000; // Opóźnienie między krokami w mikrosekundach (im mniejsze, tym silnik szybszy)

// --- Funkcja pomocnicza do ruchu silnika ---
// steps: liczba kroków do wykonania
// direction: true w jedną stronę, false w drugą
void rotateMotor(int steps, bool direction) {
    digitalWrite(PIN_DIR, direction);
    
    for (int i = 0; i < steps; i++) {
        digitalWrite(PIN_STEP, HIGH);
        delayMicroseconds(STEP_DELAY);
        digitalWrite(PIN_STEP, LOW);
        delayMicroseconds(STEP_DELAY);
    }
}

void setup() {
    // Inicjalizacja portu szeregowego do debugowania
    Serial.begin(115200);
    Serial.println("Automatyczny Stroik Gitary - Uruchomiono.");

    // Konfiguracja pinów sterownika silnika
    pinMode(PIN_STEP, OUTPUT);
    pinMode(PIN_DIR, OUTPUT);
    digitalWrite(PIN_STEP, LOW);
    digitalWrite(PIN_DIR, LOW);

    // Konfiguracja przycisków (wbudowany rezystor podciągający INPUT_PULLUP)
    // Na schemacie przyciski zwierają do masy (GND), więc stan wciśnięty = LOW
    pinMode(PIN_SW1, INPUT_PULLUP);
    pinMode(PIN_SW2, INPUT_PULLUP);
    pinMode(PIN_SW3, INPUT_PULLUP);

    // Pin analogowy jako wejście sygnału z mikrofonu/wzmacniacza
    pinMode(PIN_AUDIO_IN, INPUT);
}

void loop() {
    // 1. ODCZYT SYGNAŁU AUDIO
    // To jest uproszczone czytanie amplitudy/częstotliwości. 
    // Docelowo w tym miejscu implementuje się np. algorytm YIN lub FFT do wykrywania herców (Hz).
    int audioSample = analogRead(PIN_AUDIO_IN);
    
    // 2. OBSŁUGA PRZYCISKÓW (Manualne kręcenie / Wybór struny)
    // Przycisk SW1 - kręć w prawo
    if (digitalRead(PIN_SW1) == LOW) {
        Serial.println("SW1 wciśnięty: Kręcę w prawo...");
        rotateMotor(10, true); 
        delay(50); // Prosty debouncing
    }

    // Przycisk SW2 - kręć w lewo
    if (digitalRead(PIN_SW2) == LOW) {
        Serial.println("SW2 wciśnięty: Kręcę w lewo...");
        rotateMotor(10, false);
        delay(50);
    }

    // Przycisk SW3 - funkcja dodatkowa (np. zmiana trybu struny)
    if (digitalRead(PIN_SW3) == LOW) {
        Serial.println("SW3 wciśnięty!");
        delay(200); 
    }

    // 3. PRZYKŁADOWA LOGIKA AUTOMATYCZNEGO STROJENIA
    // Poniższy blok to szkielet: musisz podać oczekiwaną częstotliwość (Hz)
    /*
    float frequency = detectFrequency(); // Twój algorytm analizy sygnału
    float targetFrequency = 110.0;       // Np. struna A (110 Hz)
    float tolerance = 0.5;               // Tolerancja w Hz

    if (frequency > 0) { // Jeśli wykryto stabilny dźwięk
        if (frequency < (targetFrequency - tolerance)) {
            // Dźwięk za niski -> naciągnij strunę
            rotateMotor(5, true); 
        } else if (frequency > (targetFrequency + tolerance)) {
            // Dźwięk za wysoki -> poluzuj strunę
            rotateMotor(5, false);
        } else {
            // Dostrojone!
            Serial.println("Struna naciągnięta prawidłowo!");
        }
    }
    */
}